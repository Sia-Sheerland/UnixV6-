#ifndef KERNEL_ALLOCATOR
#define KERNEL_ALLOCATOR

#include "MapNode.h"
#include "Allocator.h"

class KernelAllocator
{
	/* static const member */
public:
	static const unsigned int MEMORY_MAP_ARRAY_SIZE = 0x200;				  /* ���ɷ���512������ */
	static const unsigned int KERNEL_HEAP_START_ADDR = 0x180000 + 0xC0000000; /* 1.5M����ʼΪ�ں˶��������������ں˴�0xC0000000�ſ�ʼ */
	static const unsigned int KERNEL_HEAP_SIZE = 0x80000;					  /* 512K�ں˶Ѵ�С */

	/* Functions */
public:
	KernelAllocator(Allocator *allocator);
	~KernelAllocator();
	int Initialize();

	unsigned long AllocMemory(unsigned long size);
	unsigned long FreeMemeory(unsigned long size, unsigned long memoryStartAddress);

	/* Members */
public:
	MapNode map[KernelAllocator::MEMORY_MAP_ARRAY_SIZE];

private:
	Allocator *m_pAllocator;
};

#endif
